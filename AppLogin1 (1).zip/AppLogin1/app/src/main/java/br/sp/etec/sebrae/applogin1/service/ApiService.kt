package br.sp.etec.sebrae.applogin1.service

import br.sp.etec.sebrae.applogin1.model.Login
import br.sp.etec.sebrae.applogin1.model.Usuario
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {
    @POST("/cadastro")
    fun cadastrarUsuario(
        @Body usuario: Usuario
    ) : Call<Usuario>

    @POST("/autenticar")
    fun autenticar(
        @Body login: Login
    ):Call<Boolean>
}

package br.sp.etec.sebrae.applogin1

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MuralActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_mural)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val toolbarMural = findViewById<Toolbar>(R.id.toolbarMural)
        setSupportActionBar(toolbarMural)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbarMural.setNavigationOnClickListener {
            finish()
        }

        val btnVoltarMural = findViewById<Button>(R.id.btnVoltarMural)
        btnVoltarMural.setOnClickListener {
            finish()
        }
    }
}

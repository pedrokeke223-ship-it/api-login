package br.sp.etec.sebrae.applogin1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnBoleto = findViewById<Button>(R.id.btnBoleto)
        val btnReserva = findViewById<Button>(R.id.btnReserva)
        val btnAutorizacao = findViewById<Button>(R.id.btnAutorizacao)
        val btnMural = findViewById<Button>(R.id.btnMural)
        val btnPrestacaoContas = findViewById<Button>(R.id.btnPrestacaoContas)
        val btnMudancas = findViewById<Button>(R.id.btnMudancas)
        val btnContatos = findViewById<Button>(R.id.btnContatos)

        btnBoleto.setOnClickListener {
            startActivity(Intent(this, BoletoActivity::class.java))
        }

        btnReserva.setOnClickListener {
            startActivity(Intent(this, ReservaActivity::class.java))
        }

        btnAutorizacao.setOnClickListener {
            startActivity(Intent(this, AutorizacaoActivity::class.java))
        }

        btnMural.setOnClickListener {
            startActivity(Intent(this, MuralActivity::class.java))
        }

        btnPrestacaoContas.setOnClickListener {
            startActivity(Intent(this, PrestacaoContasActivity::class.java))
        }

        btnMudancas.setOnClickListener {
            startActivity(Intent(this, MudancaActivity::class.java))
        }

        btnContatos.setOnClickListener {
            startActivity(Intent(this, ContatosActivity::class.java))
        }
    }
}

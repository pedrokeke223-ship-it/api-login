package br.sp.etec.sebrae.applogin1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import br.sp.etec.sebrae.applogin1.model.Usuario
import br.sp.etec.sebrae.applogin1.network.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CadastroActivity : AppCompatActivity() {

    val apiService = ApiClient.instance

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cadastro)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val editNome = findViewById<EditText>(R.id.editTextName)
        val editCpf = findViewById<EditText>(R.id.editTextCPF)
        val editEmail = findViewById<EditText>(R.id.editTextTextEmailAddress)
        val editTelefone = findViewById<EditText>(R.id.editTextPhone)
        val editSenha = findViewById<EditText>(R.id.editTextTextPassword2)
        val editConfirmarSenha = findViewById<EditText>(R.id.editTextTextPassword3)
        val btnCadastrar = findViewById<Button>(R.id.btnCadastrar)

        btnCadastrar.setOnClickListener {
            var usuario = Usuario(
                nome = editNome.text.toString(),
                email = editEmail.text.toString(),
                cpf = editCpf.text.toString(),
                telefone = editTelefone.text.toString(),
                senha = editSenha.text.toString()
            )
            cadastroUsuario(usuario)
        }
    }

    fun cadastroUsuario(usuario: Usuario){
        apiService.cadastrarUsuario(usuario).enqueue(object : Callback<Usuario> {
            override fun onResponse(call: Call<Usuario?>, response: Response<Usuario?>
            ) {
               if(response.isSuccessful){
                   Toast.makeText(this@CadastroActivity, "Cadastro realizado com sucesso", Toast.LENGTH_LONG).show()
               }
            }

            override fun onFailure(call: Call<Usuario?>, t: Throwable) {
                Toast.makeText(this@CadastroActivity, t.message, Toast.LENGTH_LONG).show()
            }
        })
    }
}
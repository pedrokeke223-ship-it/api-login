package br.sp.etec.sebrae.applogin1

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class PrestacaoContasActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_prestacao_contas)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val toolbarPrestacaoContas = findViewById<Toolbar>(R.id.toolbarPrestacaoContas)
        setSupportActionBar(toolbarPrestacaoContas)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbarPrestacaoContas.setNavigationOnClickListener {
            finish()
        }

        val btnAdicionarLancamento = findViewById<Button>(R.id.btnAdicionarLancamento)
        btnAdicionarLancamento.setOnClickListener {
            Toast.makeText(this, "Novo lançamento", Toast.LENGTH_SHORT).show()
        }
    }
}

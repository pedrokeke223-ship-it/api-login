package br.sp.etec.sebrae.applogin1

import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.sp.etec.sebrae.applogin1.adapter.BoletoAdapter
import br.sp.etec.sebrae.applogin1.model.Boleto


class BoletoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_boleto)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val toolbarBoleto = findViewById<Toolbar>(R.id.toolbarBoleto)
        setSupportActionBar(toolbarBoleto)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbarBoleto.setNavigationOnClickListener {
            finish()
        }

        val rc = findViewById<RecyclerView>(R.id.recyclerBoleto)
        rc.layoutManager = LinearLayoutManager(this)
        val boletos = listOf(
            Boleto(1, "Taxa Condominio Abril", 1000.0, "30/05/2026"),
            Boleto(2, "Taxa Condominio Maio", 1045.0, "30/06/2026"),
            Boleto(3, "Taxa Condominio Junho", 1094.0,"30/07/2026"),
            Boleto(4,"Taxa Condominio Julho", 1120.0, "30/08/2026")
        )
        rc.adapter = BoletoAdapter(boletos)
    }
}

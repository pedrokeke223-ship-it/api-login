package br.sp.etec.sebrae.applogin1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class AutorizacaoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_autorizacao)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val toolbarAutorizacao = findViewById<Toolbar>(R.id.toolbarAutorizacao)
        setSupportActionBar(toolbarAutorizacao)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbarAutorizacao.setNavigationOnClickListener {
            finish()
        }

        val editNomeVisitante = findViewById<EditText>(R.id.editNomeVisitante)
        val editDocumento = findViewById<EditText>(R.id.editDocumento)
        val editApartamento = findViewById<EditText>(R.id.editApartamento)
        val txtMensagemAutorizacao = findViewById<TextView>(R.id.txtMensagemAutorizacao)
        val btnSalvarAutorizacao = findViewById<Button>(R.id.btnSalvarAutorizacao)

        btnSalvarAutorizacao.setOnClickListener {
            val nome = editNomeVisitante.text.toString()
            val documento = editDocumento.text.toString()
            val apartamento = editApartamento.text.toString()

            if (nome.isEmpty() || documento.isEmpty() || apartamento.isEmpty()) {
                txtMensagemAutorizacao.text = "Todos os dados são obrigatórios"
                txtMensagemAutorizacao.setBackgroundColor(getColor(R.color.error_red))
                txtMensagemAutorizacao.visibility = TextView.VISIBLE
            } else {
                txtMensagemAutorizacao.text = "Autorização realizada com sucesso"
                txtMensagemAutorizacao.setBackgroundColor(getColor(R.color.success_green))
                txtMensagemAutorizacao.visibility = TextView.VISIBLE
            }
        }
    }
}

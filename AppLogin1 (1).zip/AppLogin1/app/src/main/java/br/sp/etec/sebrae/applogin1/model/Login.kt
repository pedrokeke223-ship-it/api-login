package br.sp.etec.sebrae.applogin1.model

import android.provider.ContactsContract

data class Login(
    val email: String,
    var senha: String
)

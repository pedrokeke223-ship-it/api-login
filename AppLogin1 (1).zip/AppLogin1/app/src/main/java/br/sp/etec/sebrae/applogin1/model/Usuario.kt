package br.sp.etec.sebrae.applogin1.model

data class Usuario(
    var nome : String,
    var cpf : String,
    var email : String,
    var telefone : String,
    var senha : String

)
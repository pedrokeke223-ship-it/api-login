package br.sp.etec.sebrae.applogin1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.util.Patterns
import android.widget.Toast
import br.sp.etec.sebrae.applogin1.model.Login
import br.sp.etec.sebrae.applogin1.network.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    val apiService = ApiClient.instance
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val editEmail = findViewById<EditText>(R.id.editTextTextEmailAddress2)
        val editSenha = findViewById<EditText>(R.id.editTextTextPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnCadastro = findViewById<Button>(R.id.btnCadastro)

        btnLogin.setOnClickListener {
            val email = editEmail.text.toString()
            val senha = editSenha.text.toString()

            val login = Login(email = email, senha = senha)
            val intent = Intent(this, HomeActivity::class.java)
            apiService.autenticar(login).enqueue(object : Callback<Boolean>{
                override fun onResponse(
                    call: Call<Boolean?>,
                    response: Response<Boolean?>
                ) {
                    if(response.isSuccessful){
                        val autenticado = response.body()
                        if(autenticado == true){
                            startActivity(intent)
                        }else{
                            Toast.makeText(this@MainActivity, "Usuário ou senha inválida!", Toast.LENGTH_LONG).show()
                        }
                    }
                }

                override fun onFailure(call: Call<Boolean?>, t: Throwable) {
                    TODO("Not yet implemented")
                }

            }
            )

            if (email.isEmpty()) {
                editEmail.error = "Digite seu email"
                editEmail.requestFocus()
            }
            else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                editEmail.error = "Digite um email válido (exemplo@email.com)"
                editEmail.requestFocus()
            }else if (senha.isEmpty()) {
                editSenha.error = "Digite sua senha"
                editSenha.requestFocus()
            } else {
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)
            }
        }

        btnCadastro.setOnClickListener {
            val intent = Intent(this, CadastroActivity::class.java)
            startActivity(intent)
        }
    }
}
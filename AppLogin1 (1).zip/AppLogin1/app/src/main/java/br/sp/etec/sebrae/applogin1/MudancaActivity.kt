package br.sp.etec.sebrae.applogin1

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MudancaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_mudanca)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val toolbarMudanca = findViewById<Toolbar>(R.id.toolbarMudanca)
        setSupportActionBar(toolbarMudanca)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbarMudanca.setNavigationOnClickListener {
            finish()
        }

        val btnCadastrarMudanca = findViewById<Button>(R.id.btnCadastrarMudanca)
        val txtMensagemMudanca = findViewById<TextView>(R.id.txtMensagemMudanca)

        btnCadastrarMudanca.setOnClickListener {
            txtMensagemMudanca.visibility = TextView.VISIBLE
        }
    }
}
